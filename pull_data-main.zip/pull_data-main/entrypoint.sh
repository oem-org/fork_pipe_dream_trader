echo "GO"
python main.py